package com.example.electron.ui.reflow;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.electron.R;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class ReflowFragment extends Fragment {

    private static final String SERVER_IP = "192.168.0.175";
    private static final int SERVER_PORT = 5050;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        Log.d("ReflowFragment", "onCreateView started");
        View root = inflater.inflate(R.layout.fragment_reflow, container, false);

        try {
            setupButtons(root);
        } catch (Exception e) {
            Log.e("ReflowFragment", "Error during onCreateView", e);
        }

        Log.d("ReflowFragment", "onCreateView finished");
        return root;
    }

    private void setupButtons(View root) {
        Log.d("ReflowFragment", "Setting up buttons");

        int[] buttonIds = {
                R.id.button, R.id.button9,
                R.id.Crome, R.id.WhatsApp, R.id.Word,
                R.id.CommandPrompt, R.id.PowerPoint, R.id.Excel,
                R.id.YouTube, R.id.Discord, R.id.facebook,
                R.id.Instagram, R.id.LinkedIn
        };

        String[] commands = {
                "button2", "button8",
                "App chrome", "App whatsapp", "App word",
                "App NotePad", "App Powerpoint", "App Excel",
                "Web YouTube", "App Discord", "Web facebook",
                "Web Instagram", "Web linkedin"
        };

        for (int i = 0; i < buttonIds.length; i++) {
            Button button = root.findViewById(buttonIds[i]);
            String command = commands[i];

            if (button == null) {
                Log.e("ReflowFragment", "Button with ID " + buttonIds[i] + " not found!");
                continue;
            }

            button.setOnClickListener(v -> {
                Log.d("ReflowFragment", "Button clicked: " + command);
                new Thread(() -> sendCommand(command)).start();
            });
        }
    }

    private void sendCommand(String command) {
        Log.d("ReflowFragment", "Sending command: " + command);

        try (Socket socket = new Socket(SERVER_IP, SERVER_PORT)) {
            OutputStream output = socket.getOutputStream();
            InputStream input = socket.getInputStream();

            output.write(command.getBytes());
            output.flush();

            byte[] buffer = new byte[1024];
            int bytesRead = input.read(buffer);
            String response = new String(buffer, 0, bytesRead);

            requireActivity().runOnUiThread(() ->
                    Toast.makeText(requireContext(), "Response: " + response, Toast.LENGTH_LONG).show());

        } catch (Exception e) {
            Log.e("ReflowFragment", "Error in sendCommand", e);
            requireActivity().runOnUiThread(() ->
                    Toast.makeText(requireContext(), "Connection failed", Toast.LENGTH_LONG).show());
        }
    }
}
