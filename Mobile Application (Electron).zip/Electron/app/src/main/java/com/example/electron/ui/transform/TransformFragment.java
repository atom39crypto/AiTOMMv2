package com.example.electron.ui.transform;

import com.example.electron.R;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class TransformFragment extends Fragment {

    private static final String TAG = "TransformFragment";

    private final String serverIp = "192.168.0.175"; // Replace with your actual server IP
    private final int serverPort = 5050;

    private WebView webView;
    private Switch navSwitch;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        Log.d(TAG, "onCreateView started");

        View root = inflater.inflate(R.layout.fragment_transform, container, false);

        // Set up Switch to toggle WebView and send commands

        // Set up buttons
        setupButtons(root);

        Log.d(TAG, "onCreateView finished");
        return root;
    }

    private void setupButtons(View root) {
        Log.d(TAG, "Setting up buttons");
        int[] buttonIds = {
                R.id.button0, R.id.button1, R.id.button2,
                R.id.button3, R.id.button4, R.id.button5,
                R.id.button6, R.id.button7, R.id.button8
        };
        String[] commands = {
                "button0", "button1", "button2",
                "button3", "button4", "button5",
                "button6", "button7", "button8"
        };

        for (int i = 0; i < buttonIds.length; i++) {
            Button button = root.findViewById(buttonIds[i]);
            String command = commands[i];
            if (button == null) {
                Log.e(TAG, "Button " + buttonIds[i] + " not found!");
                continue;
            }
            button.setOnClickListener(v -> {
                Log.d(TAG, "Button clicked: " + command);
                new Thread(() -> sendCommand(command)).start();
            });
        }
    }

    private void sendCommand(String command) {
        Log.d(TAG, "Sending command: " + command);
        try (Socket socket = new Socket(serverIp, serverPort)) {
            OutputStream output = socket.getOutputStream();
            InputStream input = socket.getInputStream();

            output.write(command.getBytes());
            output.flush();

            byte[] buffer = new byte[1024];
            int bytesRead = input.read(buffer);
            String response = new String(buffer, 0, bytesRead);

            requireActivity().runOnUiThread(() -> {
                Log.d(TAG, "Server response: " + response);
                Toast.makeText(requireContext(), "Response: " + response, Toast.LENGTH_LONG).show();
            });

        } catch (Exception e) {
            Log.e(TAG, "Error in sendCommand", e);
            requireActivity().runOnUiThread(() ->
                    Toast.makeText(requireContext(), "Connection failed", Toast.LENGTH_LONG).show());
        }
    }
}
