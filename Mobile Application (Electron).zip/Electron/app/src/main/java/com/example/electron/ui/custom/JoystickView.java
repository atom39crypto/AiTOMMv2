package com.example.electron.ui.custom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class JoystickView extends View {

    private Paint basePaint;
    private Paint knobPaint;
    private float baseRadius;
    private float knobRadius;
    private PointF center;
    private PointF touchPoint;

    public interface JoystickListener {
        void onMove(float angle, float strength);
    }

    private JoystickListener listener;

    public void setJoystickListener(JoystickListener listener) {
        this.listener = listener;
    }

    public JoystickView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        basePaint = new Paint();
        basePaint.setColor(Color.GRAY);
        basePaint.setStyle(Paint.Style.FILL);

        knobPaint = new Paint();
        knobPaint.setColor(Color.BLUE);
        knobPaint.setStyle(Paint.Style.FILL);

        center = new PointF();
        touchPoint = new PointF();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        center.set(w / 2f, h / 2f);
        touchPoint.set(center.x, center.y);
        baseRadius = Math.min(w, h) / 2.5f;
        knobRadius = baseRadius / 2.5f;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        // Draw base circle
        canvas.drawCircle(center.x, center.y, baseRadius, basePaint);
        // Draw knob
        canvas.drawCircle(touchPoint.x, touchPoint.y, knobRadius, knobPaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float dx = event.getX() - center.x;
        float dy = event.getY() - center.y;
        float distance = (float) Math.sqrt(dx * dx + dy * dy);

        if (event.getAction() != MotionEvent.ACTION_UP) {
            if (distance > baseRadius) {
                dx = dx * baseRadius / distance;
                dy = dy * baseRadius / distance;
            }
            touchPoint.set(center.x + dx, center.y + dy);

            float angle = (float) Math.toDegrees(Math.atan2(dy, dx));
            float strength = Math.min(1f, distance / baseRadius);

            if (listener != null) {
                listener.onMove(angle, strength);
            }

        } else {
            // Reset joystick to center
            touchPoint.set(center.x, center.y);
            if (listener != null) {
                listener.onMove(0, 0);
            }
        }

        invalidate(); // Redraw the joystick
        return true;
    }
}
