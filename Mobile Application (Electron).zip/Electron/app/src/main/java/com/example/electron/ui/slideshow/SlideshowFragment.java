package com.example.electron.ui.slideshow;

import android.media.MediaRecorder;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.electron.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class SlideshowFragment extends Fragment {

    private static final String TAG = "SlideshowFragment";

    private final String serverIp = "192.168.0.175"; // Replace with your server IP
    private final int serverPort = 5050;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_slideshow, container, false);

        Button playButton = root.findViewById(R.id.play);
        Button pauseButton = root.findViewById(R.id.pause);
        Button stopButton = root.findViewById(R.id.Stop);

        playButton.setOnClickListener(v -> new Thread(() -> sendCommand("PLAY")).start());
        pauseButton.setOnClickListener(v -> new Thread(() -> sendCommand("PAUSE")).start());
        stopButton.setOnClickListener(v -> new Thread(() -> sendCommand("STOP")).start());


        EditText editText = root.findViewById(R.id.textInputCommand);
        Button sendTextButton = root.findViewById(R.id.sendTextButton);
        sendTextButton.setOnClickListener(v -> {
            String textCommand = editText.getText().toString();
            if (!textCommand.isEmpty()) {
                new Thread(() -> sendCommand("TEXT:" + textCommand)).start();
            } else {
                Toast.makeText(requireContext(), "Enter some text", Toast.LENGTH_SHORT).show();
            }
        });

        SeekBar seekBar2 = root.findViewById(R.id.seekBar2);
        seekBar2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int adjustedValue = progress + 1;
                String command = "SeekBar Value: " + adjustedValue;
                Log.d(TAG, "SeekBar value changed: " + adjustedValue);
                new Thread(() -> sendCommand(command)).start();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        Button audioRecordButton = root.findViewById(R.id.audioRecordButton);
        audioRecordButton.setOnClickListener(v -> new Thread(this::recordAndSendAudio).start());

        return root;
    }

    private void sendCommand(String command) {
        Log.d(TAG, "Sending command: " + command);
        try (Socket socket = new Socket(serverIp, serverPort)) {
            OutputStream output = socket.getOutputStream();
            InputStream input = socket.getInputStream();

            output.write(command.getBytes());
            output.flush();

            byte[] buffer = new byte[1024];
            int bytesRead = input.read(buffer);
            String response = new String(buffer, 0, bytesRead);

            requireActivity().runOnUiThread(() ->
                    Toast.makeText(requireContext(), "Response: " + response, Toast.LENGTH_LONG).show());

        } catch (Exception e) {
            Log.e(TAG, "Error in sendCommand", e);
            requireActivity().runOnUiThread(() ->
                    Toast.makeText(requireContext(), "Connection failed", Toast.LENGTH_LONG).show());
        }
    }

    private void recordAndSendAudio() {
        File audioFile = new File(requireContext().getCacheDir(), "recorded_audio.m4a");

        MediaRecorder mediaRecorder = new MediaRecorder();
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4); // instead of THREE_GPP
        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC); // instead of AMR_NB
        mediaRecorder.setOutputFile(audioFile.getAbsolutePath());


        try {
            mediaRecorder.prepare();
            mediaRecorder.start();

            requireActivity().runOnUiThread(() ->
                    Toast.makeText(requireContext(), "Recording started...", Toast.LENGTH_SHORT).show());

            Thread.sleep(5000); // Record for 5 seconds

            mediaRecorder.stop();
            mediaRecorder.release();

            requireActivity().runOnUiThread(() ->
                    Toast.makeText(requireContext(), "Recording completed", Toast.LENGTH_SHORT).show());

            sendAudioFile(audioFile);

        } catch (Exception e) {
            Log.e(TAG, "Recording failed", e);
            requireActivity().runOnUiThread(() ->
                    Toast.makeText(requireContext(), "Recording failed", Toast.LENGTH_SHORT).show());
        }
    }

    private void sendAudioFile(File audioFile) {
        try (Socket socket = new Socket(serverIp, serverPort);
             OutputStream output = socket.getOutputStream();
             FileInputStream fileInput = new FileInputStream(audioFile)) {

            output.write("AUDIO_FILE\n".getBytes());
            output.flush();
            Thread.sleep(200); // Give server a moment

            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = fileInput.read(buffer)) != -1) {
                output.write(buffer, 0, bytesRead);
            }
            output.flush();

            requireActivity().runOnUiThread(() ->
                    Toast.makeText(requireContext(), "Audio file sent", Toast.LENGTH_SHORT).show());

        } catch (Exception e) {
            Log.e(TAG, "Sending audio file failed", e);
            requireActivity().runOnUiThread(() ->
                    Toast.makeText(requireContext(), "Audio file send failed", Toast.LENGTH_SHORT).show());
        }
    }
}
